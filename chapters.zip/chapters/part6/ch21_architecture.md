# Chapter 21. 시스템 아키텍처 설계

> **PART 6**: 종합 프로젝트 – AI 환경 무드 컨트롤러

---

## 📚 이 챕터에서 배울 내용

- [ ] 시스템 아키텍처를 설계할 수 있다
- [ ] 데이터 흐름을 정의할 수 있다
- [ ] 컴포넌트 간 인터페이스를 설계할 수 있다

**예상 소요 시간**: 30분

---

## 🎯 학습 목표

### 핵심 개념

- **아키텍처**: 시스템 구조와 컴포넌트 관계
- **데이터 흐름**: 정보가 이동하는 경로
- **인터페이스**: 컴포넌트 간 통신 방법

---

## 🏗️ 시스템 아키텍처

### 3계층 구조

```
┌─────────────────────────────────────┐
│      Edge Layer (엣지 계층)          │
│  ┌──────────────────────────────┐   │
│  │     헥사보드 (ESP32)          │   │
│  │  • DHT11 센서                 │   │
│  │  • 조도 센서                  │   │
│  │  • NeoPixel LED              │   │
│  │  • MicroPython                │   │
│  └──────────────────────────────┘   │
└──────────────┬──────────────────────┘
               │ MQTT (TLS)
┌──────────────┴──────────────────────┐
│   Communication Layer (통신 계층)    │
│  ┌──────────────────────────────┐   │
│  │    MQTT Broker (HiveMQ)      │   │
│  │  • Topic 관리                 │   │
│  │  • 메시지 중개                │   │
│  │  • QoS 보장                   │   │
│  └──────────────────────────────┘   │
└──────────────┬──────────────────────┘
               │ MQTT (TLS)
┌──────────────┴──────────────────────┐
│    Intelligence Layer (지능 계층)    │
│  ┌──────────────────────────────┐   │
│  │   Python AI Server            │   │
│  │  • 데이터 수집                │   │
│  │  • AI 분석 (OpenAI)           │   │
│  │  • 명령 생성                  │   │
│  │  • 상태 관리                  │   │
│  └──────────────────────────────┘   │
└─────────────────────────────────────┘
```

---

## 📡 데이터 흐름

### 센서 → AI → 제어 흐름

**1. 센서 데이터 수집 (5초 주기)**

```
헥사보드 센서
  ├─ DHT11: 온도 25°C, 습도 60%
  ├─ 조도 센서: 800
  └─ 타임스탬프: 1234567890

↓ JSON 변환

{
  "board": "A",
  "temperature": 25,
  "humidity": 60,
  "light": 800,
  "timestamp": 1234567890
}

↓ MQTT Publish

Topic: hexaboard/A/sensor/data
```

**2. AI 분석 (10초 주기)**

```
Python Server
  ├─ 최근 10개 데이터 수집
  ├─ 평균 계산
  ├─ OpenAI API 호출
  └─ 무드 판단

↓ 무드 결정

{
  "mood": "Perfect",
  "reason": "온도와 습도가 이상적",
  "recommendation": "현재 상태 유지"
}

↓ LED 명령 생성

{
  "action": "led_color",
  "color": [0, 255, 0],
  "pattern": "solid",
  "brightness": 80
}

↓ MQTT Publish

Topic: hexaboard/A/control/led
```

**3. LED 제어 실행**

```
헥사보드
  ├─ MQTT Subscribe
  ├─ 명령 파싱
  ├─ LED 제어 실행
  └─ 상태 확인 전송

↓ 실행 결과

Topic: hexaboard/A/status
Message: "led_updated"
```

---

## 🔄 상태 다이어그램

### 무드 전환 로직

```
        [Perfect]
         ↙  ↓  ↘
    [Cold] [Good] [Hot]
         ↘  ↓  ↙
        [Humid]
```

**전환 조건**:

```python
if 22 <= temp <= 26 and 40 <= humid <= 60:
    mood = "Perfect"
elif 20 <= temp <= 28 and 35 <= humid <= 65:
    mood = "Good"
elif temp < 20:
    mood = "Cold"
elif temp > 28:
    mood = "Hot"
elif humid > 65:
    mood = "Humid"
```

---

## 📋 Topic 설계

### MQTT Topic 구조

**센서 데이터**:
```
hexaboard/{board_id}/sensor/data
  → {"temperature": 25, "humidity": 60, "light": 800}
```

**제어 명령**:
```
hexaboard/{board_id}/control/led
  → {"action": "led_color", "color": [0, 255, 0]}
```

**상태 업데이트**:
```
hexaboard/{board_id}/status
  → "online" | "offline" | "led_updated"
```

**AI 분석 결과** (선택):
```
hexaboard/{board_id}/analysis
  → {"mood": "Perfect", "reason": "..."}
```

---

## 🗂️ 데이터 모델

### 센서 데이터 모델

```python
SensorData = {
    "board": str,           # 보드 ID (예: "A")
    "temperature": float,   # 온도 (°C)
    "humidity": float,      # 습도 (%)
    "light": int,           # 조도 (0-4095)
    "timestamp": int        # Unix timestamp
}
```

### 무드 분석 모델

```python
MoodAnalysis = {
    "mood": str,            # "Perfect" | "Good" | "Cold" | "Hot" | "Humid"
    "score": float,         # 0.0-1.0 (환경 품질 점수)
    "reason": str,          # 무드 판단 이유
    "recommendation": str,  # 권장 조치
    "timestamp": int
}
```

### LED 제어 모델

```python
LEDCommand = {
    "action": str,          # "led_color" | "led_pattern" | "led_off"
    "color": [int, int, int],  # RGB (0-255)
    "pattern": str,         # "solid" | "blink" | "pulse"
    "brightness": int,      # 0-100 (%)
    "duration": int         # 지속 시간 (초, 선택)
}
```

---

## 🔌 컴포넌트 인터페이스

### 헥사보드 인터페이스

**입력 (Subscribe)**:
- `hexaboard/A/control/led` - LED 제어 명령
- `hexaboard/A/control/mode` - 모드 변경 (선택)

**출력 (Publish)**:
- `hexaboard/A/sensor/data` - 센서 데이터 (5초마다)
- `hexaboard/A/status` - 상태 정보

**API (함수)**:
```python
def read_sensors() -> SensorData
def set_led(color: tuple, pattern: str) -> bool
def get_status() -> str
```

### Python AI Server 인터페이스

**입력 (Subscribe)**:
- `hexaboard/+/sensor/data` - 모든 보드 센서 데이터

**출력 (Publish)**:
- `hexaboard/{id}/control/led` - LED 제어 명령
- `hexaboard/{id}/analysis` - 분석 결과 (선택)

**API (함수)**:
```python
def analyze_environment(data: SensorData) -> MoodAnalysis
def generate_command(mood: MoodAnalysis) -> LEDCommand
def send_command(board_id: str, cmd: LEDCommand) -> bool
```

---

## ⚙️ 설정 파일 구조

### 환경 변수 (.env)

```bash
# MQTT 설정
MQTT_BROKER=abc123.s1.eu.hivemq.cloud
MQTT_PORT=8883
MQTT_USER=hexaboard
MQTT_PASSWORD=your_password

# OpenAI 설정
OPENAI_API_KEY=sk-proj-XXXX

# 시스템 설정
BOARD_ID=A
SENSOR_INTERVAL=5
CONTROL_INTERVAL=10

# 무드 임계값
TEMP_MIN_PERFECT=22
TEMP_MAX_PERFECT=26
HUMID_MIN_PERFECT=40
HUMID_MAX_PERFECT=60
```

### 무드 설정 (config.json)

```json
{
  "moods": {
    "Perfect": {
      "color": [0, 255, 0],
      "pattern": "solid",
      "brightness": 80,
      "conditions": {
        "temp_min": 22,
        "temp_max": 26,
        "humid_min": 40,
        "humid_max": 60
      }
    },
    "Good": {
      "color": [255, 255, 0],
      "pattern": "solid",
      "brightness": 70
    },
    "Cold": {
      "color": [0, 0, 255],
      "pattern": "blink",
      "brightness": 60
    },
    "Hot": {
      "color": [255, 0, 0],
      "pattern": "blink",
      "brightness": 60
    },
    "Humid": {
      "color": [128, 0, 255],
      "pattern": "pulse",
      "brightness": 70
    }
  }
}
```

---

## 🛡️ 에러 처리 전략

### 센서 오류

```python
try:
    sensor.measure()
    temp = sensor.temperature()
except:
    temp = None  # 이전 값 사용 또는 기본값
    log_error("Sensor read failed")
```

### MQTT 연결 끊김

```python
def on_disconnect(client, userdata, rc):
    while True:
        try:
            client.reconnect()
            break
        except:
            time.sleep(5)  # 5초 후 재시도
```

### AI API 오류

```python
try:
    analysis = call_openai_api(data)
except:
    # 규칙 기반 폴백
    analysis = rule_based_analysis(data)
```

---

## 📊 성능 요구사항

### 응답 시간

| 작업 | 목표 시간 | 최대 시간 |
|------|-----------|-----------|
| 센서 읽기 | 0.1초 | 0.5초 |
| MQTT 전송 | 0.2초 | 1초 |
| AI 분석 | 1초 | 3초 |
| LED 제어 | 0.1초 | 0.3초 |
| **전체 흐름** | **2초** | **5초** |

### 리소스 사용

- **메모리**: 헥사보드 < 50KB, Python < 100MB
- **네트워크**: < 1KB/초 (평균)
- **CPU**: 헥사보드 < 20%, Python < 30%

---

## 🔐 보안 고려사항

### 통신 보안

- ✅ MQTT over TLS (포트 8883)
- ✅ Username/Password 인증
- ✅ API 키 환경 변수 관리

### 데이터 프라이버시

- ✅ 개인 정보 미포함
- ✅ 로컬 처리 우선
- ✅ 데이터 보관 기간 제한

---

## 📝 핵심 정리

### 아키텍처 원칙

1. **모듈화**: 각 컴포넌트 독립적
2. **확장성**: 새로운 보드 추가 용이
3. **신뢰성**: 에러 처리 및 폴백
4. **효율성**: 리소스 최소화
5. **보안성**: TLS 및 인증

### 데이터 흐름

```
센서(5초) → MQTT → AI 분석(10초) → 명령 생성 → MQTT → LED 제어
```

---

## ❓ 자주 묻는 질문

### Q1. 왜 10초마다 AI 분석하나요?
**A**: 비용 절감과 성능 균형. 환경은 빠르게 변하지 않으므로 10초면 충분합니다.

### Q2. 헥사보드가 오프라인이 되면?
**A**: 마지막 명령 상태 유지. 재연결 시 자동으로 다시 동기화됩니다.

### Q3. 여러 보드를 동시에 제어할 수 있나요?
**A**: 네. Board ID로 구분하여 각각 독립적으로 제어 가능합니다.

---

## 🚀 다음 단계

시스템 아키텍처 설계가 완료되었습니다!

**다음 챕터에서는**:
- 실제 코드 구현
- 단계별 통합
- 테스트 및 디버깅

---

**🎉 Chapter 21 완료!**  
이제 실제 구현을 시작할 준비가 되었습니다!

