# Chapter 6. 버튼 + 네오픽셀로 만드는 상태 머신

> **PART 2**: 헥사보드 기본 제어 – 버튼과 네오픽셀

---

## 📚 이 챕터에서 배울 내용

- [ ] 버튼으로 LED 색상을 바꿀 수 있다
- [ ] 상태 머신의 개념을 이해할 수 있다
- [ ] 간단한 게임을 만들 수 있다

**예상 소요 시간**: 40분

---

## 🎯 학습 목표

### 핵심 개념

- **상태 머신**: 상태를 저장하고 전환하는 방식
- **모드 전환**: 버튼으로 여러 모드 바꾸기
- **인터랙션**: 입력과 출력을 결합

---

## 📖 상태 머신이란?

### 간단한 예시

전등 스위치를 생각해봅시다:

```
[켜짐] ←→ [꺼짐]
  ↑         ↑
버튼 누름  버튼 누름
```

**상태**: 켜짐 또는 꺼짐  
**전환**: 버튼을 누르면 상태가 바뀜

### 프로그램에서의 상태 머신

```python
# 상태 저장
state = "빨강"

# 버튼을 누르면
if button_pressed:
    if state == "빨강":
        state = "초록"
    elif state == "초록":
        state = "파랑"
    elif state == "파랑":
        state = "빨강"
```

---

## 🔧 실습 준비

### 필요한 것

- [x] 헥사보드 × 1
- [x] USB 케이블 × 1

---

## 💻 실습 1: 버튼으로 LED 켜기/끄기

### 토글 스위치 만들기

**코드**:

```python
# 파일명: ch06_led_toggle.py
# 버튼으로 LED 켜기/끄기

from machine import Pin
import neopixel
import time

# 설정
button_a = Pin(35, Pin.IN, Pin.PULL_DOWN)
np = neopixel.NeoPixel(Pin(23), 25)

# 상태 변수
is_on = False  # LED가 켜져 있는지
prev_button = 0

print("버튼 A를 눌러서 LED를 켜고 끄세요!")

while True:
    curr_button = button_a.value()

    # 버튼을 눌렀을 때 (0 → 1)
    if prev_button == 0 and curr_button == 1:
        is_on = not is_on  # 상태 반전!

        if is_on:
            # 전체 LED 켜기
            for i in range(25):
                np[i] = (0, 255, 0)  # 초록색
            print("LED ON")
        else:
            # 전체 LED 끄기
            for i in range(25):
                np[i] = (0, 0, 0)
            print("LED OFF")

        np.write()

    prev_button = curr_button
    time.sleep(0.05)
```

**동작**:

- 버튼 A를 누를 때마다 LED가 켜졌다 꺼졌다 반복

---

## 💻 실습 2: 버튼으로 색상 바꾸기

### 3가지 색상 순환

**코드**:

```python
# 파일명: ch06_color_cycle.py
# 버튼으로 색상 바꾸기

from machine import Pin
import neopixel
import time

button_a = Pin(35, Pin.IN, Pin.PULL_DOWN)
np = neopixel.NeoPixel(Pin(23), 25)

# 색상 리스트
colors = [
    (255, 0, 0),    # 빨강
    (0, 255, 0),    # 초록
    (0, 0, 255)     # 파랑
]

# 상태 변수
color_index = 0  # 현재 색상 번호
prev_button = 0

def fill(color):
    """전체 LED를 같은 색으로"""
    for i in range(25):
        np[i] = color
    np.write()

# 처음 색상 표시
fill(colors[color_index])
print(f"색상: {color_index} - {colors[color_index]}")

print("버튼 A를 눌러서 색상을 바꾸세요!")

while True:
    curr_button = button_a.value()

    # 버튼 눌림 감지
    if prev_button == 0 and curr_button == 1:
        # 다음 색상으로
        color_index = (color_index + 1) % 3

        # LED 업데이트
        fill(colors[color_index])
        print(f"색상: {color_index} - {colors[color_index]}")

    prev_button = curr_button
    time.sleep(0.05)
```

**핵심 아이디어**:

- `color_index`로 현재 색상 추적
- `(color_index + 1) % 3`: 0 → 1 → 2 → 0 순환

---

## 💻 실습 3: 두 버튼으로 제어하기

### 버튼 A: 색상 변경, 버튼 B: 끄기

**코드**:

```python
# 파일명: ch06_two_buttons.py
# 두 버튼으로 제어

from machine import Pin
import neopixel
import time

button_a = Pin(35, Pin.IN, Pin.PULL_DOWN)
button_b = Pin(34, Pin.IN, Pin.PULL_DOWN)
np = neopixel.NeoPixel(Pin(23), 25)

colors = [
    (255, 0, 0),    # 빨강
    (0, 255, 0),    # 초록
    (0, 0, 255),    # 파랑
    (255, 255, 0),  # 노랑
    (255, 0, 255)   # 보라
]

color_index = 0
prev_a = 0
prev_b = 0

def fill(color):
    for i in range(25):
        np[i] = color
    np.write()

fill(colors[color_index])

print("버튼 A: 색상 변경")
print("버튼 B: 끄기")

while True:
    curr_a = button_a.value()
    curr_b = button_b.value()

    # 버튼 A: 색상 변경
    if prev_a == 0 and curr_a == 1:
        color_index = (color_index + 1) % 5
        fill(colors[color_index])
        print(f"색상 {color_index+1}")

    # 버튼 B: 끄기
    if prev_b == 0 and curr_b == 1:
        fill((0, 0, 0))
        color_index = 0  # 초기화
        print("LED OFF")

    prev_a = curr_a
    prev_b = curr_b
    time.sleep(0.05)
```

---

## 💻 실습 4: 간단한 게임 – 빠르게 누르기

### 반응 속도 게임

**코드**:

```python
# 파일명: ch06_reaction_game.py
# 반응 속도 게임

from machine import Pin
import neopixel
import time
import random

button_a = Pin(35, Pin.IN, Pin.PULL_DOWN)
np = neopixel.NeoPixel(Pin(23), 25)

def fill(color):
    for i in range(25):
        np[i] = color
    np.write()

print("=" * 30)
print("  반응 속도 게임")
print("=" * 30)
print("빨간색이 나오면 빠르게 버튼을 누르세요!")
print()

prev_button = 0

while True:
    # 모두 끄기
    fill((0, 0, 0))

    # 랜덤 대기 시간 (1~3초)
    wait_time = random.uniform(1, 3)
    print(f"대기 중... ({wait_time:.1f}초)")
    time.sleep(wait_time)

    # 빨간색 켜기!
    fill((255, 0, 0))
    start_time = time.time()
    print("지금!")

    # 버튼 누를 때까지 대기
    while True:
        curr_button = button_a.value()

        if prev_button == 0 and curr_button == 1:
            # 반응 시간 계산
            reaction_time = time.time() - start_time

            # 결과 표시
            if reaction_time < 0.3:
                print(f"⚡ 굉장해요! {reaction_time:.3f}초")
                fill((255, 255, 0))  # 노란색
            elif reaction_time < 0.5:
                print(f"👍 빨라요! {reaction_time:.3f}초")
                fill((0, 255, 0))  # 초록색
            else:
                print(f"💪 좋아요! {reaction_time:.3f}초")
                fill((0, 0, 255))  # 파란색

            time.sleep(2)
            break

        prev_button = curr_button
        time.sleep(0.01)

    print()
```

**게임 설명**:

1. LED가 꺼진 상태로 대기
2. 랜덤 시간 후 빨간색 켜짐
3. 빠르게 버튼 누르기!
4. 반응 시간 측정 및 결과 표시

---

## ✅ 동작 확인

**정상 동작하면**:

- ✅ 실습 1: 버튼으로 LED가 켜지고 꺼짐
- ✅ 실습 2: 버튼으로 색상이 순환함
- ✅ 실습 3: 두 버튼이 각각 다르게 동작
- ✅ 실습 4: 게임이 정상 작동

---

## 🎓 핵심 요약

### 오늘 배운 것

1. **상태 머신**: 상태를 저장하고 전환
2. **버튼 + LED**: 입력과 출력 결합
3. **모드 전환**: 여러 상태 순환
4. **게임 만들기**: 타이밍과 피드백

### 핵심 코드 패턴

```python
# 상태 저장
state = 0

# 버튼 눌림 감지
if prev == 0 and curr == 1:
    # 상태 변경
    state = (state + 1) % 3

    # LED 업데이트
    update_led(state)
```

---

## 🚀 도전 과제

### 과제 1: 밝기 조절 ⭐️

버튼 A: 밝기 증가  
버튼 B: 밝기 감소

**힌트**: 밝기 변수를 만들고 0~255 범위로 제한

### 과제 2: 패턴 선택 ⭐️⭐️

버튼을 누를 때마다 다른 패턴 표시:

- 패턴 1: 전체 빨강
- 패턴 2: 십자가
- 패턴 3: 테두리만

**힌트**: 각 패턴을 함수로 만들기

### 과제 3: 타이머 ⭐️⭐️⭐️

버튼 A를 누르면 5초 카운트다운:

- 5초: 초록색
- 3초: 노란색
- 1초: 빨간색
- 0초: 깜빡임

**힌트**: `time.time()`으로 경과 시간 계산

---

## 📝 학습 체크

- [ ] 버튼으로 LED를 제어할 수 있나요?
- [ ] 상태 머신의 개념을 이해했나요?
- [ ] 두 버튼을 함께 사용할 수 있나요?
- [ ] 간단한 게임을 만들 수 있나요?

**완료 시간**: \_\_\_시 \_\_\_분

---

## 🎉 PART 2 완료!

축하합니다! PART 2를 모두 마쳤습니다.

**PART 2에서 배운 것**:

- ✅ 버튼 2개 제어
- ✅ 네오픽셀 25개 제어
- ✅ 버튼 + LED 결합
- ✅ 상태 머신 개념

**다음은?**  
PART 3에서는 온습도 센서와 조도 센서를 연결합니다!

---

**다음 챕터**: Chapter 7 - 온습도 센서 이해와 연결

---

> **💡 TIP**: 상태 머신은 복잡한 프로그램을 만들 때 매우 유용합니다. 나중에 AI 제어에서도 사용됩니다!

---

**챕터 작성**: 2025-11-25  
**작성자**: AIoT eBook Team
