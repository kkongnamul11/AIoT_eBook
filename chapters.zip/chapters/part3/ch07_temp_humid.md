# Chapter 7. 온습도 센서 이해와 연결

> **PART 3**: 온습도 센서 & 조도 센서 연결하기

---

## 📚 이 챕터에서 배울 내용

- [ ] 온습도 센서(DHT11)를 연결할 수 있다
- [ ] 온도와 습도를 측정할 수 있다
- [ ] 측정값을 화면에 출력할 수 있다

**예상 소요 시간**: 40분

---

## 🎯 학습 목표

### 핵심 개념

- **온습도 센서**: 온도와 습도를 동시에 측정하는 센서
- **DHT11**: 가장 많이 사용되는 온습도 센서
- **디지털 센서**: 데이터를 디지털로 전송

---

## 📖 온습도 센서란?

### DHT11 vs DHT22

**DHT11** (우리가 사용):

- 온도: 0~50°C (±2°C 오차)
- 습도: 20~90% (±5% 오차)
- 저렴함
- 초보자에게 적합

**DHT22** (고급):

- 온도: -40~80°C (±0.5°C)
- 습도: 0~100% (±2%)
- 더 정확하지만 비쌈

> 💡 **팁**: 이 책에서는 DHT11을 사용하지만 DHT22도 같은 코드로 동작합니다!

### DHT11 핀 구성

```
DHT11 센서 (3핀)
┌─────────┐
│  DHT11  │
│         │
│ 1  2  3 │
└─┬──┬──┬─┘
  │  │  │
VCC DATA GND
```

- **VCC**: 전원 (3.3V)
- **DATA**: 데이터 신호
- **GND**: 접지

---

## 🔧 실습 준비

### 필요한 것

- [x] 헥사보드 × 1
- [x] DHT11 센서 모듈 × 1 (저항 내장)
- [x] 3핀 케이블 × 1
- [x] USB 케이블 × 1

> **💡 TIP**: DHT11 센서 모듈은 필요한 저항이 내장되어 있고, 3핀 케이블로 헥사보드에 바로 연결할 수 있어 매우 간편합니다!

### 센서 연결하기

```
DHT11          헥사보드
--------------------------
VCC (1번)  →  3.3V
DATA (2번) →  PIN1 (GPIO 32)
GND (3번)  →  GND
```

**연결 순서**:

1. 헥사보드의 전원을 끕니다 (USB 제거)
2. 점퍼 케이블로 연결합니다
3. 연결을 다시 확인합니다
4. USB를 연결합니다

⚠️ **주의**: VCC와 GND를 반대로 연결하면 센서가 고장날 수 있습니다!

---

## 💻 실습 1: DHT11 라이브러리 설치

### dht 모듈 확인

MicroPython에는 `dht` 모듈이 기본 내장되어 있습니다!

**테스트 코드**:

```python
# 파일명: ch07_test_import.py
# DHT 모듈 확인

try:
    import dht
    print("✓ dht 모듈이 있습니다!")
except ImportError:
    print("✗ dht 모듈이 없습니다")
```

실행하면 "dht 모듈이 있습니다!"가 나와야 합니다.

---

## 💻 실습 2: 첫 번째 온습도 측정

### 온도와 습도 읽기

**코드**:

```python
# 파일명: ch07_dht_basic.py
# 온습도 센서 기본

from machine import Pin
import dht
import time

# DHT11 센서 설정 (GPIO 32번)
sensor = dht.DHT11(Pin(32))

print("온습도 센서 테스트")
print("-" * 30)

# 한 번 측정
sensor.measure()  # 측정 시작
temp = sensor.temperature()  # 온도 (°C)
humid = sensor.humidity()    # 습도 (%)

print(f"온도: {temp}°C")
print(f"습도: {humid}%")
```

**코드 설명**:

- `dht.DHT11(Pin(32))`: DHT11 센서를 GPIO 32번으로 설정
- `sensor.measure()`: 측정 명령 (꼭 필요!)
- `sensor.temperature()`: 온도 읽기
- `sensor.humidity()`: 습도 읽기

### 실행 결과 예시

```
온습도 센서 테스트
------------------------------
온도: 24°C
습도: 65%
```

---

## 💻 실습 3: 실시간 모니터링

### 1초마다 측정하기

**코드**:

```python
# 파일명: ch07_dht_monitor.py
# 실시간 온습도 모니터링

from machine import Pin
import dht
import time

sensor = dht.DHT11(Pin(32))

print("=" * 40)
print("  실시간 온습도 모니터링")
print("=" * 40)
print("Ctrl+C로 종료")
print()

count = 0

while True:
    try:
        # 측정
        sensor.measure()
        temp = sensor.temperature()
        humid = sensor.humidity()

        # 출력
        count += 1
        print(f"[{count}] 온도: {temp}°C | 습도: {humid}%")

        # 2초 대기 (DHT11은 최소 2초 간격 필요)
        time.sleep(2)

    except OSError as e:
        print("센서 읽기 실패:", e)
        time.sleep(2)
```

**실행 결과**:

```
========================================
  실시간 온습도 모니터링
========================================
Ctrl+C로 종료

[1] 온도: 24°C | 습도: 65%
[2] 온도: 24°C | 습도: 66%
[3] 온도: 25°C | 습도: 65%
```

> 💡 **팁**: DHT11은 최소 2초 간격으로 측정해야 합니다!

---

## 💻 실습 4: LED로 온도 표시

### 온도에 따라 색상 변경

**코드**:

```python
# 파일명: ch07_temp_led.py
# 온도에 따라 LED 색상 변경

from machine import Pin
import dht
import neopixel
import time

sensor = dht.DHT11(Pin(32))
np = neopixel.NeoPixel(Pin(23), 25)

def fill(color):
    """전체 LED를 같은 색으로"""
    for i in range(25):
        np[i] = color
    np.write()

print("온도 표시 LED")
print("낮음: 파랑 | 보통: 초록 | 높음: 빨강")
print()

while True:
    try:
        sensor.measure()
        temp = sensor.temperature()
        humid = sensor.humidity()

        # 온도에 따라 색상 선택
        if temp < 20:
            color = (0, 0, 255)  # 파랑 (추움)
            status = "낮음"
        elif temp < 26:
            color = (0, 255, 0)  # 초록 (적당)
            status = "보통"
        else:
            color = (255, 0, 0)  # 빨강 (더움)
            status = "높음"

        # LED 업데이트
        fill(color)

        print(f"온도: {temp}°C ({status}) | 습도: {humid}%")

        time.sleep(2)

    except OSError as e:
        print("오류:", e)
        time.sleep(2)
```

**동작**:

- 20°C 미만: 파란색 (추움)
- 20~25°C: 초록색 (적당)
- 26°C 이상: 빨간색 (더움)

---

## ✅ 동작 확인

**정상 동작하면**:

- ✅ 온도 값이 출력됨 (예: 24°C)
- ✅ 습도 값이 출력됨 (예: 65%)
- ✅ 2초마다 업데이트됨
- ✅ LED 색상이 온도에 따라 변함

---

## 🐛 문제 해결

### 문제 1: "OSError" 에러

**증상**:

```
OSError: [Errno 116] ETIMEDOUT
```

**원인**:

- 센서가 제대로 연결되지 않음
- 측정 간격이 너무 짧음

**해결 방법**:

1. 연결 확인:
   - VCC → 3.3V
   - DATA → GPIO 32
   - GND → GND
2. 2초 이상 간격으로 측정
3. 센서를 다시 연결

### 문제 2: 값이 이상해요

**증상**:

- 온도가 너무 높거나 낮음 (예: 50°C)
- 습도가 0% 또는 100%

**원인**:

- 센서가 초기화 중
- 불량 센서

**해결 방법**:

1. 10초 정도 기다리기
2. 헥사보드 재시작
3. 센서를 다른 것으로 교체

### 문제 3: 측정값이 안 변해요

**증상**:

- 계속 같은 값만 나옴

**원인**:

- DHT11은 측정이 느림 (2초 간격)
- 실제로 온습도가 안정적

**해결 방법**:

- 손가락으로 센서를 살짝 감싸면 온도와 습도가 올라갑니다
- 입김을 불면 습도가 올라갑니다

---

## 🎓 핵심 요약

### 오늘 배운 것

1. **DHT11 센서**: 온도와 습도를 동시 측정
2. **센서 연결**: VCC, DATA, GND 3핀 연결
3. **측정 방법**: `measure()` → `temperature()` / `humidity()`
4. **측정 간격**: 최소 2초

### 핵심 코드

```python
# 온습도 센서 사용
sensor = dht.DHT11(Pin(32))

sensor.measure()  # 측정
temp = sensor.temperature()  # 온도
humid = sensor.humidity()    # 습도

time.sleep(2)  # 2초 대기 (중요!)
```

---

## 🚀 도전 과제

### 과제 1: 경고 시스템 ⭐️

온도가 28°C 이상이면 LED를 빨간색으로 깜빡이게 만들어보세요.

**힌트**: `while` 안에 `if temp > 28` 조건 추가

### 과제 2: 최고/최저 온도 ⭐️⭐️

측정한 온도 중 최고 온도와 최저 온도를 기록하고 출력하세요.

**힌트**: `max_temp = 0`, `min_temp = 100` 변수 사용

### 과제 3: 쾌적도 표시 ⭐️⭐️

온도와 습도를 모두 고려해서 쾌적도를 표시하세요:

- 쾌적: 온도 20~25°C, 습도 40~60%
- 보통: 그 외
- 불쾌: 온도 30°C 이상 또는 습도 80% 이상

---

## 📝 학습 체크

- [ ] DHT11 센서를 연결했나요?
- [ ] 온도와 습도를 측정할 수 있나요?
- [ ] LED로 온도를 표시할 수 있나요?
- [ ] 2초 간격의 중요성을 이해했나요?

**완료 시간**: \_\_\_시 \_\_\_분

---

**다음 챕터**: Chapter 8 - 조도 센서 이해와 연결

빛의 밝기를 측정해봅시다!

---

> **💡 TIP**: DHT11 센서는 실내 환경 모니터링에 아주 유용합니다. 스마트 홈의 시작입니다!

---

**챕터 작성**: 2025-11-25  
**작성자**: AIoT eBook Team
